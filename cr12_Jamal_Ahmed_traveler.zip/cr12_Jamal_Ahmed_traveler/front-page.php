<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <title><?php bloginfo('name'); ?></title>
  <!-- Bootstrap core CSS -->
  <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
  <?php wp_head(); ?>
</head>
<body>
  <div class="blog-masthead">
    <div class="container">
      <nav class="blog-nav">
        <?php
          wp_nav_menu( array(
              'menu'              => 'primary',
              'theme_location'    => 'primary',
              'depth'             => 2,
              'container'         => 'div',
              'container_class'   => 'collapse navbar-collapse',
              'container_id'      => 'bs-example-navbar-collapse-1',
              'menu_class'        => 'nav navbar-nav',
              'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
              'walker'            => new WP_Bootstrap_Navwalker())
          );
      ?>
      </nav>
    </div>
  </div>
  <section class="showcase">
    <div class="container">
      <h2>Mount Everest traveler </h2>
      <p class="lead" style="color:darkblue">How Solo Travel Can Change Your Life.</p>
     
    </div>
  </section>
  <section class="boxes">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="box">
              <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/city.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at. </p>
          
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
           <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/beach.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/lake.jpg" alt="image">
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div><br><br>
      <div class="row">
        <div class="col-md-4">
          <div class="box">
        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/sand.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at. </p>
          
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
           <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/sea.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
             <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/forest.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div><br><br>
      <div class="row">
        <div class="col-md-4">
          <div class="box">
        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/artich.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at. </p>
          
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
           <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/hamburg.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
             <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/forest.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div><br><br>
      <div class="row">
        <div class="col-md-4">
          <div class="box">
        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/dorf.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at. </p>
          
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
           <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/forest.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/segway.jpg" alt="image">
            <h3>Time Alone is Time With a Friend</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. 
            Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php get_footer(); ?>